const { fork } = require('child_process');
const path = require('path');

const services = [
  { name: 'api-gateway', path: './domains/core-platform-services/api-gateway-service/dist/main.js', port: 3000 },
  { name: 'auth-service', path: './domains/core-platform-services/auth-service/dist/main.js', port: 3001 },
  { name: 'file-upload-service', path: './domains/core-platform-services/file-upload-service/dist/main.js', port: 3009 },
  { name: 'academy-backend', path: './domains/academy/backend/dist/src/main.js', port: 3002 },
  { name: 'con-tech-backend', path: './domains/con-tech/backend/dist/src/main.js', port: 3003 },
  { name: 'careers-service', path: './domains/core-platform-services/careers-service/dist/main.js', port: 3004 },
  { name: 'events-backend', path: './domains/events/backend/dist/src/main.js', port: 3005 },
];

console.log('--- starting alikohub microservices ---');

services.forEach(service => {
  console.log(`starting ${service.name} (port ${service.port}) ...`);
  
  const child = fork(path.resolve(__dirname, service.path), [], {
    env: {
      ...process.env,
      PORT: service.port,
      NODE_ENV: 'production'
    }
  });

  child.on('message', (msg) => {
    console.log(`[${service.name}] ${msg}`);
  });

  child.on('error', (err) => {
    console.error(`[${service.name}] ERROR:`, err);
  });

  child.on('exit', (code) => {
    console.log(`[${service.name}] exited with code ${code}`);
  });
});
